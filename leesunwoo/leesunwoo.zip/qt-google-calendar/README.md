# qt-google-calendar
Automatically exported from code.google.com/p/qt-google-calendar

Qt C++ client created by Integrated Computer Solutions, Inc. (ICS) that uses the Google Calendar API. The Google Calendar API lets you develop client applications that create new events, edit or delete existing events, and search for events. Once you register your application in the Google API Console, you can use this API as part of your Google account.

ICS is the largest independent supplier of professional services, training, and add-on products for the Qt® cross-platform framework. Learn more from www.ics.com. 
# qt-google-calendar
# qt-google-calendar
